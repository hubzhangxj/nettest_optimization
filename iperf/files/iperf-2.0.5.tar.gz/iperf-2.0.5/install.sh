#! /bin/bash
build_iperf() {

    arch=`uname -i`   	
    #set -e
    if [ $arch = "aarch64" ] 
    then 
       para=aarch64-unknown-linux-gnu
    fi 
    ./configure  --build=$para
    make && make install
}

build_iperf

